from flask import Flask, render_template_string, redirect, url_for, request, session, jsonify
import random
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'your-secret-key'

# بيانات المشرف
ADMIN_CREDENTIALS = {
    'username': 'admin',
    'password': 'admin123'
}

# قالب صفحة تسجيل دخول المشرف
ADMIN_LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل دخول المشرف</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .error-message {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h2 class="text-center mb-4">تسجيل دخول المشرف</h2>
            <form action="/admin/login" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">اسم المستخدم</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">كلمة المرور</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                {% if error %}
                <div class="error-message">{{ error }}</div>
                {% endif %}
                <button type="submit" class="btn btn-primary w-100">تسجيل الدخول</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

# قالب صفحة تسجيل الدخول
LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - نظام المندوبين</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo img {
            width: 100px;
            height: 100px;
        }
        [dir="ltr"] {
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="logo">
                <h1>👤</h1>
                <h2 class="text-primary" data-translate="system-title">نظام المندوبين</h2>
            </div>
            <div class="card">
                <div class="card-body p-4">
                    <h4 class="card-title text-center mb-4" data-translate="login">تسجيل الدخول</h4>
                    <form action="/login" method="post">
                        <div class="mb-3">
                            <label class="form-label" data-translate="username">اسم المستخدم</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" data-translate="phone">رقم الهاتف</label>
                            <input type="tel" name="phone" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2" data-translate="login-btn">دخول</button>
                    </form>
                </div>
            </div>
            <div class="text-center mt-3">
                <select class="form-select" id="languageSelect" onchange="setLanguage(this.value)">
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                    <option value="bn">বাংলা</option>
                </select>
            </div>
        </div>
    </div>
    <script>
        const translations = {
            ar: {
                'system-title': 'نظام المندوبين',
                'login': 'تسجيل الدخول',
                'username': 'اسم المستخدم',
                'phone': 'رقم الهاتف',
                'login-btn': 'دخول',
                'dir': 'rtl'
            },
            en: {
                'system-title': 'Delegate System',
                'login': 'Login',
                'username': 'Username',
                'phone': 'Phone Number',
                'login-btn': 'Login',
                'dir': 'ltr'
            },
            bn: {
                'system-title': 'প্রতিনিধি সিস্টেম',
                'login': 'লগইন',
                'username': 'ব্যবহারকারীর নাম',
                'phone': 'ফোন নম্বর',
                'login-btn': 'লগইন',
                'dir': 'ltr'
            }
        };

        function setLanguage(lang) {
            document.documentElement.lang = lang;
            document.documentElement.dir = translations[lang]['dir'];
            
            const elements = document.querySelectorAll('[data-translate]');
            elements.forEach(element => {
                const key = element.getAttribute('data-translate');
                if (translations[lang][key]) {
                    element.textContent = translations[lang][key];
                }
            });

            // تغيير اتجاه النموذج بناءً على اللغة
            const form = document.querySelector('form');
            if (translations[lang]['dir'] === 'ltr') {
                form.classList.add('text-start');
            } else {
                form.classList.remove('text-start');
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

# قالب لوحة المندوب
DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-translate="dashboard">لوحة المندوب</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        .card { 
            margin-bottom: 20px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .btn-lg { 
            width: 100%;
            margin-bottom: 10px;
            border-radius: 10px;
        }
        .welcome-header {
            background-color: #f8f9fa;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 15px;
            text-align: center;
        }
        [dir="ltr"] {
            text-align: left;
        }
        #attendanceStatus {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="welcome-header">
            <h2><span data-translate="welcome">مرحباً</span> {username}!</h2>
            <p class="text-muted"><span data-translate="phone">رقم الهاتف</span>: {phone}</p>
            <a href="/logout" class="btn btn-outline-danger" data-translate="logout">تسجيل خروج</a>
        </div>
        
        <!-- قسم الحضور -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title" data-translate="attendance">تسجيل الحضور</h5>
                <button onclick="markAttendance('check-in')" class="btn btn-success btn-lg mb-2" data-translate="check-in">تسجيل الحضور</button>
                <button onclick="markAttendance('check-out')" class="btn btn-danger btn-lg" data-translate="check-out">تسجيل الانصراف</button>
                <div id="attendanceStatus" class="alert"></div>
            </div>
        </div>

        <!-- قسم تسليم النقد -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title" data-translate="cash">تسليم النقد</h5>
                <div class="mb-3">
                    <label class="form-label" data-translate="amount">المبلغ</label>
                    <input type="number" class="form-control" data-translate="amount-placeholder" placeholder="أدخل المبلغ">
                </div>
                <button class="btn btn-primary btn-lg" data-translate="submit-cash">تسليم النقد</button>
            </div>
        </div>

        <!-- قسم مشاركة الموقع -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title" data-translate="location">مشاركة الموقع</h5>
                <button class="btn btn-info btn-lg mb-2" data-translate="start-sharing">بدء مشاركة الموقع</button>
                <button class="btn btn-secondary btn-lg" data-translate="stop-sharing">إيقاف مشاركة الموقع</button>
            </div>
        </div>

        <!-- قسم اللغة -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title" data-translate="language">تغيير اللغة</h5>
                <select class="form-select" id="languageSelect" onchange="setLanguage(this.value)">
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                    <option value="bn">বাংলা</option>
                </select>
            </div>
        </div>
    </div>
    <script>
        const translations = {
            ar: {
                'dashboard': 'لوحة المندوب',
                'welcome': 'مرحباً',
                'phone': 'رقم الهاتف',
                'logout': 'تسجيل خروج',
                'attendance': 'تسجيل الحضور',
                'check-in': 'تسجيل الحضور',
                'check-out': 'تسجيل الانصراف',
                'cash': 'تسليم النقد',
                'amount': 'المبلغ',
                'amount-placeholder': 'أدخل المبلغ',
                'submit-cash': 'تسليم النقد',
                'location': 'مشاركة الموقع',
                'start-sharing': 'بدء مشاركة الموقع',
                'stop-sharing': 'إيقاف مشاركة الموقع',
                'language': 'تغيير اللغة',
                'dir': 'rtl'
            },
            en: {
                'dashboard': 'Delegate Dashboard',
                'welcome': 'Welcome',
                'phone': 'Phone',
                'logout': 'Logout',
                'attendance': 'Attendance',
                'check-in': 'Check In',
                'check-out': 'Check Out',
                'cash': 'Cash Submission',
                'amount': 'Amount',
                'amount-placeholder': 'Enter amount',
                'submit-cash': 'Submit Cash',
                'location': 'Location Sharing',
                'start-sharing': 'Start Sharing Location',
                'stop-sharing': 'Stop Sharing Location',
                'language': 'Change Language',
                'dir': 'ltr'
            },
            bn: {
                'dashboard': 'প্রতিনিধি ড্যাশবোর্ড',
                'welcome': 'স্বাগতম',
                'phone': 'ফোন',
                'logout': 'লগআউট',
                'attendance': 'উপস্থিতি',
                'check-in': 'চেক ইন',
                'check-out': 'চেক আউট',
                'cash': 'নগদ জমা',
                'amount': 'পরিমাণ',
                'amount-placeholder': 'পরিমাণ লিখুন',
                'submit-cash': 'নগদ জমা দিন',
                'location': 'অবস্থান শেয়ারিং',
                'start-sharing': 'অবস্থান শেয়ার শুরু করুন',
                'stop-sharing': 'অবস্থান শেয়ার বন্ধ করুন',
                'language': 'ভাষা পরিবর্তন করুন',
                'dir': 'ltr'
            }
        };

        function setLanguage(lang) {
            document.documentElement.lang = lang;
            document.documentElement.dir = translations[lang]['dir'];
            
            // تغيير ملف CSS لـ Bootstrap بناءً على اتجاه اللغة
            const bootstrapLink = document.querySelector('link[href*="bootstrap"]');
            if (translations[lang]['dir'] === 'ltr') {
                bootstrapLink.href = 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css';
            } else {
                bootstrapLink.href = 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css';
            }

            const elements = document.querySelectorAll('[data-translate]');
            elements.forEach(element => {
                const key = element.getAttribute('data-translate');
                if (translations[lang][key]) {
                    if (element.tagName === 'INPUT' && element.type === 'text') {
                        element.placeholder = translations[lang][key];
                    } else {
                        element.textContent = translations[lang][key];
                    }
                }
            });
        }
    </script>
    <script>
        async function markAttendance(type) {
            try {
                // الحصول على الموقع
                const position = await getCurrentPosition();
                
                // إرسال طلب تسجيل الحضور
                const response = await fetch('/api/attendance', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        type: type,
                        lat: position ? position.coords.latitude : null,
                        lng: position ? position.coords.longitude : null
                    })
                });
                
                const data = await response.json();
                
                // عرض رسالة النجاح
                const statusDiv = document.getElementById('attendanceStatus');
                statusDiv.textContent = data.message;
                statusDiv.className = 'alert alert-success';
                statusDiv.style.display = 'block';
                
                // إخفاء الرسالة بعد 3 ثواني
                setTimeout(() => {
                    statusDiv.style.display = 'none';
                }, 3000);
                
            } catch (error) {
                console.error('Error:', error);
                const statusDiv = document.getElementById('attendanceStatus');
                statusDiv.textContent = 'حدث خطأ أثناء تسجيل الحضور';
                statusDiv.className = 'alert alert-danger';
                statusDiv.style.display = 'block';
            }
        }
        
        function getCurrentPosition() {
            return new Promise((resolve, reject) => {
                if (!navigator.geolocation) {
                    resolve(null);
                    return;
                }
                
                navigator.geolocation.getCurrentPosition(
                    position => resolve(position),
                    error => {
                        console.warn('Error getting location:', error);
                        resolve(null);
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 5000,
                        maximumAge: 0
                    }
                );
            });
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

# قالب لوحة تحكم المشرف
ADMIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المشرف</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        .stat-card {
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .table-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        #map {
            height: 400px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">لوحة تحكم المشرف</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#delegates">المندوبين</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#attendance">الحضور</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#cash">النقد</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#locations">المواقع</a>
                    </li>
                </ul>
                <span class="navbar-text">
                    مرحباً، المشرف
                </span>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- الإحصائيات -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <div class="stat-icon text-primary">
                            <i class="bi bi-people-fill"></i>
                        </div>
                        <h5 class="card-title">المندوبين</h5>
                        <h3 class="card-text">{{ total_delegates }}</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <div class="stat-icon text-success">
                            <i class="bi bi-check-circle-fill"></i>
                        </div>
                        <h5 class="card-title">الحضور اليوم</h5>
                        <h3 class="card-text">{{ today_attendance }}</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <div class="stat-icon text-warning">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                        <h5 class="card-title">النقد المستلم</h5>
                        <h3 class="card-text">{{ total_cash }} ر.س</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <div class="stat-icon text-info">
                            <i class="bi bi-geo-alt-fill"></i>
                        </div>
                        <h5 class="card-title">المندوبين النشطين</h5>
                        <h3 class="card-text">{{ active_delegates }}</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- المندوبين -->
        <div id="delegates" class="table-container">
            <h4 class="mb-4">قائمة المندوبين</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>رقم الهاتف</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    {% for delegate in delegates %}
                    <tr>
                        <td>{{ delegate.name }}</td>
                        <td>{{ delegate.phone }}</td>
                        <td>
                            <span class="badge {% if delegate.status == 'نشط' %}bg-success{% else %}bg-secondary{% endif %}">
                                {{ delegate.status }}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary">تعديل</button>
                            <button class="btn btn-sm btn-danger">حظر</button>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>

        <!-- الحضور -->
        <div id="attendance" class="table-container">
            <h4 class="mb-4">سجل الحضور</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>المندوب</th>
                        <th>النوع</th>
                        <th>الوقت</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    {% for record in attendance %}
                    <tr>
                        <td>{{ record.name }}</td>
                        <td>{{ record.type }}</td>
                        <td>{{ record.time }}</td>
                        <td>{{ record.date }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>

        <!-- النقد -->
        <div id="cash" class="table-container">
            <h4 class="mb-4">تسليم النقد</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>المندوب</th>
                        <th>المبلغ</th>
                        <th>التاريخ</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    {% for submission in cash_submissions %}
                    <tr>
                        <td>{{ submission.name }}</td>
                        <td>{{ submission.amount }} ر.س</td>
                        <td>{{ submission.date }}</td>
                        <td>
                            <span class="badge {% if submission.status == 'مقبول' %}bg-success{% else %}bg-warning{% endif %}">
                                {{ submission.status }}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-success">قبول</button>
                            <button class="btn btn-sm btn-danger">رفض</button>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>

        <!-- المواقع -->
        <div id="locations" class="table-container">
            <h4 class="mb-4">مواقع المندوبين</h4>
            <div id="map" class="mb-4"></div>
            <table class="table">
                <thead>
                    <tr>
                        <th>المندوب</th>
                        <th>آخر تحديث</th>
                        <th>الموقع</th>
                    </tr>
                </thead>
                <tbody>
                    {% for location in locations %}
                    <tr>
                        <td>{{ location.name }}</td>
                        <td>{{ location.last_update }}</td>
                        <td>
                            <a href="#" onclick="centerMap({{ location.lat }}, {{ location.lng }})">عرض على الخريطة</a>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY"></script>
    <script>
        let map;
        let markers = [];

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: 24.7136, lng: 46.6753 },
                zoom: 12
            });

            // إضافة المواقع على الخريطة
            {% for location in locations %}
            addMarker({{ location.lat }}, {{ location.lng }}, "{{ location.name }}");
            {% endfor %}
        }

        function addMarker(lat, lng, title) {
            const marker = new google.maps.Marker({
                position: { lat: lat, lng: lng },
                map: map,
                title: title
            });
            markers.push(marker);
        }

        function centerMap(lat, lng) {
            map.setCenter({ lat: lat, lng: lng });
            map.setZoom(15);
        }

        // تهيئة الخريطة
        window.onload = initMap;
    </script>
</body>
</html>
"""

# إضافة بيانات تجريبية
SAMPLE_DATA = {
    'delegates': [
        {'id': 1, 'name': 'أحمد محمد', 'phone': '0501234567', 'status': 'نشط'},
        {'id': 2, 'name': 'محمد علي', 'phone': '0507654321', 'status': 'نشط'},
        {'id': 3, 'name': 'خالد عبدالله', 'phone': '0503456789', 'status': 'غير نشط'},
    ],
    'attendance': [
        {'delegate_id': 1, 'name': 'أحمد محمد', 'type': 'حضور', 'time': '08:30', 'date': '2025-01-16'},
        {'delegate_id': 2, 'name': 'محمد علي', 'type': 'حضور', 'time': '08:45', 'date': '2025-01-16'},
        {'delegate_id': 1, 'name': 'أحمد محمد', 'type': 'انصراف', 'time': '16:30', 'date': '2025-01-16'},
    ],
    'cash_submissions': [
        {'delegate_id': 1, 'name': 'أحمد محمد', 'amount': 5000, 'date': '2025-01-16', 'status': 'مقبول'},
        {'delegate_id': 2, 'name': 'محمد علي', 'amount': 3000, 'date': '2025-01-16', 'status': 'قيد المراجعة'},
    ],
    'locations': [
        {'delegate_id': 1, 'name': 'أحمد محمد', 'lat': 24.7136, 'lng': 46.6753, 'last_update': '10:30'},
        {'delegate_id': 2, 'name': 'محمد علي', 'lat': 24.7142, 'lng': 46.6748, 'last_update': '10:35'},
    ]
}

@app.route('/')
def index():
    if 'username' in session:
        return render_template_string(
            DASHBOARD_TEMPLATE,
            username=session['username'],
            phone=session['phone']
        )
    return render_template_string(LOGIN_TEMPLATE)

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    phone = request.form.get('phone')
    session['username'] = username
    session['phone'] = phone
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_CREDENTIALS['username'] and password == ADMIN_CREDENTIALS['password']:
            session['admin'] = True
            return redirect(url_for('admin'))
        else:
            return render_template_string(ADMIN_LOGIN_TEMPLATE, error='اسم المستخدم أو كلمة المرور غير صحيحة')
            
    return render_template_string(ADMIN_LOGIN_TEMPLATE)

@app.route('/admin')
def admin():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
        
    # حساب الإحصائيات
    total_delegates = len(SAMPLE_DATA['delegates'])
    active_delegates = len([d for d in SAMPLE_DATA['delegates'] if d['status'] == 'نشط'])
    today = datetime.now().strftime('%Y-%m-%d')
    today_attendance = len([a for a in SAMPLE_DATA['attendance'] if a['date'] == today and a['type'] == 'حضور'])
    total_cash = sum([s['amount'] for s in SAMPLE_DATA['cash_submissions'] if s['status'] == 'مقبول'])
    
    return render_template_string(
        ADMIN_TEMPLATE,
        delegates=SAMPLE_DATA['delegates'],
        attendance=SAMPLE_DATA['attendance'],
        cash_submissions=SAMPLE_DATA['cash_submissions'],
        locations=SAMPLE_DATA['locations'],
        total_delegates=total_delegates,
        active_delegates=active_delegates,
        today_attendance=today_attendance,
        total_cash=total_cash
    )

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect(url_for('admin_login'))

@app.route('/api/attendance', methods=['POST'])
def mark_attendance():
    if 'username' not in session:
        return jsonify({'error': 'غير مسجل الدخول'}), 401
        
    data = request.get_json()
    attendance_type = data.get('type')  # 'check-in' or 'check-out'
    lat = data.get('lat')
    lng = data.get('lng')
    
    # تحويل نوع الحضور إلى العربية
    attendance_type_ar = 'حضور' if attendance_type == 'check-in' else 'انصراف'
    
    # إنشاء سجل حضور جديد
    new_attendance = {
        'delegate_id': 1,  # في التطبيق الحقيقي، سيكون هذا معرف المندوب الفعلي
        'name': session['username'],
        'type': attendance_type_ar,
        'time': datetime.now().strftime('%H:%M'),
        'date': datetime.now().strftime('%Y-%m-%d')
    }
    
    # إضافة السجل إلى قائمة الحضور
    SAMPLE_DATA['attendance'].append(new_attendance)
    
    # تحديث موقع المندوب
    if lat and lng:
        new_location = {
            'delegate_id': 1,
            'name': session['username'],
            'lat': lat,
            'lng': lng,
            'last_update': datetime.now().strftime('%H:%M')
        }
        
        # تحديث أو إضافة موقع جديد
        location_updated = False
        for loc in SAMPLE_DATA['locations']:
            if loc['delegate_id'] == 1:
                loc.update(new_location)
                location_updated = True
                break
        
        if not location_updated:
            SAMPLE_DATA['locations'].append(new_location)
    
    return jsonify({
        'message': f'تم تسجيل {attendance_type_ar} بنجاح',
        'attendance': new_attendance
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not Admin.query.filter_by(username='admin').first():
            admin = Admin(
                username='admin',
                password_hash=bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
            )
            db.session.add(admin)
            db.session.commit()
    port = int(os.environ.get('PORT', 10000))
    app.run(host='0.0.0.0', port=port)
