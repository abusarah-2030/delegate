const serverless = require('serverless-http');
const { spawn } = require('child_process');
const express = require('express');
const app = express();

// Start Flask app as a child process
const flaskProcess = spawn('python', ['app.py']);

// Forward requests to Flask
app.all('*', (req, res) => {
  // Forward request to Flask
});

module.exports.handler = serverless(app);
