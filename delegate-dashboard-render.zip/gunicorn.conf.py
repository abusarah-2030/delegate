bind = "0.0.0.0:10000"
workers = 2
threads = 4
worker_class = "gthread"
worker_connections = 1000
timeout = 0
keepalive = 2
