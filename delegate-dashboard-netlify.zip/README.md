# Delegate Dashboard

A multilingual (English/Arabic/Bengali) web application for delegates to manage their daily activities including attendance, cash submissions, and location sharing. The application includes a SQLite database for storing delegate information and activities.

## Features

- Multilingual support (English/Arabic/Bengali)
- Secure login system with database storage
- Attendance tracking (Check-in/Check-out)
- Cash submission with receipt upload
- Real-time location sharing
- Responsive design using Bootstrap 5
- SQLite database for data persistence

## Project Structure

```
delegate-dashboard/
├── database/
│   ├── delegate.db
│   └── schema.sql
├── uploads/
├── css/
│   └── styles.css
├── js/
│   ├── app.js
│   └── translations.js
├── app.py
├── requirements.txt
├── gunicorn.conf.py
├── nginx.conf
├── start.sh
├── index.html
├── admin.html
└── README.md
```

## Local Development Setup

1. Clone or download this repository
2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start the development server:
   ```bash
   python app.py
   ```
4. Open http://localhost:5000 in your browser

## Production Deployment

### Prerequisites
- Ubuntu/Debian server
- Python 3.9 or higher
- Nginx
- Domain name (optional)

### Server Setup Steps

1. Update system and install requirements:
```bash
sudo apt update
sudo apt upgrade -y
sudo apt install python3-pip python3-venv nginx -y
```

2. Create a directory for the application:
```bash
sudo mkdir -p /var/www/delegate-dashboard
sudo chown -R $USER:$USER /var/www/delegate-dashboard
```

3. Copy all project files to the server:
```bash
# Using SCP (run this from your local machine):
scp -r * user@your_server:/var/www/delegate-dashboard/
```

4. Set up Python virtual environment:
```bash
cd /var/www/delegate-dashboard
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

5. Configure Nginx:
```bash
# Copy nginx configuration
sudo cp nginx.conf /etc/nginx/sites-available/delegate-dashboard
sudo ln -s /etc/nginx/sites-available/delegate-dashboard /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

6. Set up systemd service:
```bash
sudo nano /etc/systemd/system/delegate-dashboard.service
```

Add the following content:
```ini
[Unit]
Description=Delegate Dashboard
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/delegate-dashboard
Environment="PATH=/var/www/delegate-dashboard/venv/bin"
ExecStart=/var/www/delegate-dashboard/venv/bin/gunicorn --config gunicorn.conf.py app:app

[Install]
WantedBy=multi-user.target
```

7. Start the service:
```bash
sudo systemctl start delegate-dashboard
sudo systemctl enable delegate-dashboard
```

8. Check status:
```bash
sudo systemctl status delegate-dashboard
```

Your application should now be running on:
- http://your_server_ip (if no domain)
- http://your_domain.com (if you have configured a domain)

## Security Notes

1. Change the SECRET_KEY in app.py before deployment
2. Set up SSL/TLS using Let's Encrypt for HTTPS
3. Configure firewall (UFW) to allow only necessary ports
4. Regularly backup the database

## Database Schema

The application uses SQLite with the following tables:

- `delegates`: Stores delegate information and credentials
- `attendance`: Records check-in/check-out times
- `cash_submissions`: Tracks cash submissions and receipts
- `locations`: Stores delegate location data
